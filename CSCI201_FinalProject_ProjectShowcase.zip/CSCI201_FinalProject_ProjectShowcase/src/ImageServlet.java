

import java.io.IOException;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ViewImage
 */
@WebServlet("/ImageServlet")
public class ImageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ImageServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		System.out.println(id);
		Connection conn = null;
	    Statement st = null;
	    ResultSet rs = null;
	    Blob image = null;
	    byte[] imgData = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
	        conn = DriverManager.getConnection("jdbc:mysql://mydbinstance.cwkjzjcxdcml.us-east-2.rds.amazonaws.com:3306/mydb?user=cs201&password=finalproject&useSSL=false");
	        st = conn.createStatement();
	        rs = st.executeQuery("SELECT ImageBlob FROM Image WHERE fk_Image_Project_ID='" + id + "'");
	        if (rs.next()) {
	        		System.out.println("not null");
	        		image = rs.getBlob(1);
	        		imgData = image.getBytes(1, (int) image.length());
	        		response.setContentType("image/gif");
	        		OutputStream o = response.getOutputStream();
	        		o.write(imgData);
	        		o.flush(); 
	        		o.close();
	        }
	        else {
	        		System.out.println("image not found for given id");
	        }
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		finally {
			try {
				conn.close();
				st.close();
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
