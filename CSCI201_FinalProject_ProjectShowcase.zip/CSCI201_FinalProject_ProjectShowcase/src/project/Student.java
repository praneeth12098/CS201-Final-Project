package project;

public class Student {
	private String fname;
	private String lname;
	private int studentID;
	private String email;
	private String year;
	private String major;
	private String username;
	private String school;
	
	public Student(String fname2, String lname2, String email2, String username2, Integer studentID2, String year2,
			String school2, String major2) {
		fname = fname2;
		lname = lname2;
		email = email2;
		username = username2;
		studentID = studentID2;
		year = year2;
		school = school2;
		major = major2;
	}
	
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public int getStudentID() {
		return studentID;
	}
	public void setStudentID(int studentID) {
		this.studentID = studentID;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getMajor() {
		return major;
	}
	public void setMajor(String major) {
		this.major = major;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getSchool() {
		return school;
	}
	public void setSchool(String school) {
		this.school = school;
	}
}
