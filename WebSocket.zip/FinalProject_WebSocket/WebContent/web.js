/**
 * 
 */
//window.onload = init;
var socket; 
function connect(){
	console.log("In connect function");
	socket = new WebSocket("ws://localhost:8080/FinalProject_WebSocket/ws");
	socket.onmessage = onMessage;
	
	socket.onopen = function(event){
		document.getElementById("test").innerHTML += "Connected!"; 
	}
	
	socket.onclose = function(event){
		document.getElementById("test").innerHTML += "Closing!"; 
	}
}

function onMessage(event) {
    var message = JSON.parse(event.data);

    if(device.action == "sendN"){
    		var text = message.description;
    		document.getElementById("test").innerHTML += text; 
    }
}

function sendNotification(){
	console.log("In send function");
	var Notification = {
	        action: "sendN",
	        description: "I am sending a message to everyone."
	    };
	socket.send(JSON.stringify(Notification));
}