package networking; 

import java.io.StringReader;
import java.util.Vector;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

import objects.Student;

@ServerEndpoint(value = "/ws")
public class ServerSocket {
	private static SessionHandler sessionHandler = new SessionHandler();
	
	@OnOpen
    public void open(Session session) {
        sessionHandler.addSession(session);
        System.out.println("Added a new session.");
    }
	
	@OnMessage
    public void handleMessage(String message, Session session) {
		
		try (JsonReader reader = Json.createReader(new StringReader(message))) {
            JsonObject jsonMessage = reader.readObject();
            
            if ("add".equals(jsonMessage.getString("action"))) {
                Student student = new Student();
                student.setName(jsonMessage.getString("name"));
                sessionHandler.addStudent(student);
            }

            if ("remove".equals(jsonMessage.getString("action"))) {
                int id = (int) jsonMessage.getInt("id");
                sessionHandler.removeStudent(id);
            }

            if ("toggle".equals(jsonMessage.getString("action"))) {
                int id = (int) jsonMessage.getInt("id");
                sessionHandler.toggleStudent(id);
            }
            if ("sendN".equals(jsonMessage.getString("action"))) {
            		System.out.println("Server received the message");
            		sessionHandler.sendToAllConnectedSessions(jsonMessage);
            }
        }
    }
	
	@OnClose
	public void close(Session session) {
		System.out.println("Disconnecting!");
		sessionHandler.removeSession(session);
	}
	
	@OnError
	public void error(Throwable error) {
		System.out.println("Error!");
		error.printStackTrace(System.out);
	}
}
