package networking;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.json.JsonObject;
import javax.json.spi.JsonProvider;
import javax.websocket.Session;

import objects.Student;

public class SessionHandler {
	private int studentID = 0; 
	private final Set<CustomSession> sessions = new HashSet<>();
    private final Set<Student> students = new HashSet<>();
    private Map<Session, CustomSession> sessionToId = new HashMap<Session, CustomSession>();
    int index = 0; 
    public void addSession(Session session) {
    		CustomSession customSession = new CustomSession(index, session);
		index++; 
    		sessions.add(customSession);
    		sessionToId.put(session, customSession);
        for (Student student : students) {
            JsonObject addMessage = createAddMessage(student);
            sendToSession(customSession, addMessage);
        }
    }

    public void removeSession(Session session) {
        CustomSession cs = sessionToId.get(session);
    		sessions.remove(cs);
    }
    
    public List<Student> getDevices() {
        return new ArrayList<>(students);
    }

    public void addStudent(Student student) {
    		student.setId(studentID);
        students.add(student);
        studentID++;
        JsonObject addMessage = createAddMessage(student);
        sendToAllConnectedSessions(addMessage);
    }

    public void removeStudent(int id) {
    		Student student = getStudentById(id);
        if (student != null) {
            students.remove(student);
            JsonProvider provider = JsonProvider.provider();
            JsonObject removeMessage = provider.createObjectBuilder()
                    .add("action", "remove")
                    .add("id", id)
                    .build();
            sendToAllConnectedSessions(removeMessage);
        }
    }

    public void toggleStudent(int id) {
    }

    private Student getStudentById(int id) {
    		for (Student student : students) {
            if (student.getId() == id) {
                return student;
            }
        }
        return null;
    }

    private JsonObject createAddMessage(Student device) {
    		JsonProvider provider = JsonProvider.provider();
        JsonObject addMessage = provider.createObjectBuilder()
                .add("action", "add")
                .add("id", device.getId())
                .add("name", device.getName())
                .build();
        return addMessage;
    }

    public void sendToAllConnectedSessions(JsonObject message) {
    		System.out.println("Broadcasting a message.");
    		for (CustomSession session : sessions) {
            sendToSession(session, message);
        }
    }

    private void sendToSession(CustomSession session, JsonObject message) {
    		try {
            session.getSession().getBasicRemote().sendText(message.toString());
        } catch (IOException ex) {
            sessions.remove(session);
        }
    }

}