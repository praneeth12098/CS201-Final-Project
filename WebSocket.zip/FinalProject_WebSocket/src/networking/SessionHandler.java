package networking;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.json.JsonObject;
import javax.json.spi.JsonProvider;
import javax.websocket.Session;

import objects.Student;

public class SessionHandler {
	private int studentID = 0; 
	private final Set<Session> sessions = new HashSet<>();
    private final Set<Student> students = new HashSet<>();
    
    public void addSession(Session session) {
        sessions.add(session);
        for (Student student : students) {
            JsonObject addMessage = createAddMessage(student);
            sendToSession(session, addMessage);
        }
    }

    public void removeSession(Session session) {
        sessions.remove(session);
    }
    
    public List<Student> getDevices() {
        return new ArrayList<>(students);
    }

    public void addStudent(Student student) {
    		student.setId(studentID);
        students.add(student);
        studentID++;
        JsonObject addMessage = createAddMessage(student);
        sendToAllConnectedSessions(addMessage);
    }

    public void removeStudent(int id) {
    		Student student = getStudentById(id);
        if (student != null) {
            students.remove(student);
            JsonProvider provider = JsonProvider.provider();
            JsonObject removeMessage = provider.createObjectBuilder()
                    .add("action", "remove")
                    .add("id", id)
                    .build();
            sendToAllConnectedSessions(removeMessage);
        }
    }

    public void toggleStudent(int id) {
    }

    private Student getStudentById(int id) {
    		for (Student student : students) {
            if (student.getId() == id) {
                return student;
            }
        }
        return null;
    }

    private JsonObject createAddMessage(Student device) {
    		JsonProvider provider = JsonProvider.provider();
        JsonObject addMessage = provider.createObjectBuilder()
                .add("action", "add")
                .add("id", device.getId())
                .add("name", device.getName())
                .build();
        return addMessage;
    }

    private void sendToAllConnectedSessions(JsonObject message) {
    		for (Session session : sessions) {
            sendToSession(session, message);
        }
    }

    private void sendToSession(Session session, JsonObject message) {
    		try {
            session.getBasicRemote().sendText(message.toString());
        } catch (IOException ex) {
            sessions.remove(session);
        }
    }

}