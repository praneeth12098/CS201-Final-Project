
import java.io.IOException;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project.*;

@WebServlet("/ViewProjects")
public class ViewProjects extends HttpServlet {
	public static final long serialVersionUID = 1;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    Connection conn = null;
	    Statement st = null;
	    ResultSet rs = null;
	    HttpSession session = request.getSession();
	    try {
	    		Class.forName("com.mysql.jdbc.Driver");
	        conn = DriverManager.getConnection("jdbc:mysql://mydbinstance.cwkjzjcxdcml.us-east-2.rds.amazonaws.com:3306/mydb?user=cs201&password=finalproject&useSSL=false");
	        st = conn.createStatement();
	        
	        //get all students from database and make map of id to student name
	        	rs = st.executeQuery("SELECT * from Student");
	        HashMap<Integer, Student> students = new HashMap<Integer, Student>();
	        while (rs.next()) {
		        	String fname = rs.getString("Fname");
		        	String lname = rs.getString("Lname");
		        	String email = rs.getString("Email");
		        	String username = rs.getString("Username");
		        	Integer studentID = rs.getInt("StudentID");
		        	String year = rs.getString("Standing");
		        	String school = rs.getString("School");
		        	String major = rs.getString("Major");
		        	Student s = new Student(fname, lname, email, username, studentID, year, school, major);
		        	
//		        	System.out.println ("Name = " + name);
//		        	System.out.println ("studentID = " + studentID);
//		        	System.out.println("");
		        	students.put(studentID, s);
	        }
	        session.setAttribute("students", students);
	        
	        if (rs != null) {
    				rs.close();
    			}
	        //get all projects from database
	        rs = st.executeQuery("SELECT * from Projects");
	        HashMap<Integer, Project> projects = new HashMap<Integer, Project>();
	        ArrayList<Project> projectList = new ArrayList<Project>();
	        while (rs.next()) {
	        		String name = rs.getString("Name");
	        		String shortDescription = rs.getString("ShortDescription");
	        		String description = rs.getString("Description");
	        		if (description.equals("I got dumped by my girlfriend and I created this website to humiliate her.")) {
	        			continue;
	        		}
	        		String category = rs.getString("Category");
	        		Integer studentID = rs.getInt("StudentID");
	        		Integer projectID = rs.getInt("ProjectID");
	        		Date timestamp = rs.getTimestamp("Timestamp");
	        		Blob code = rs.getBlob("CodeBlob");
	        		String fileName = rs.getString("Code");
	        		if (name.equals("AVL Tree") && shortDescription.equals("")) {
	        			continue;
	        		}
	        		byte[] codeFile = code.getBytes(1, (int) code.length());
	        		Project project = new Project(name, category, shortDescription, description, studentID, projectID, codeFile, fileName, timestamp);
	        		projects.put(projectID, project);
	        		projectList.add(project);
	        		System.out.println("Project title:" + name);
	        		System.out.println("Project category:" + category);
	        		System.out.println("Project description:" + description);
	        		System.out.println("Project ID:" + projectID);
	        		System.out.println("Project studentID:" + studentID);
	        		System.out.println("");
	        }
	 	        
	        if (rs != null) {
				rs.close();
			}
	        
	        rs = st.executeQuery("SELECT * from Language");
	        while (rs.next()) {
	        		String language = rs.getString("Language");
	        		System.out.println("language: " + language);
	        		int pID = rs.getInt("fk_Language_ProjectID");
	        		System.out.println("pId: " + pID);
	        		if (projects.get(pID) != null) {
	        			projects.get(pID).addLanguage(language);
	        		}
	        }
	        
	     
	        session.setAttribute("projects", projects);
	        session.setAttribute("projectList", projectList);
	        
	        System.out.println("first name: " + request.getAttribute("fname"));
	        
	        request.setAttribute("username", request.getAttribute("username"));
			request.setAttribute("lname", request.getAttribute("lname"));
			request.setAttribute("company", request.getAttribute("company"));
			request.setAttribute("email", request.getAttribute("email"));
			request.setAttribute("recruiterID", request.getAttribute("recruiterID"));
	        
	        if (session.getAttribute("fname2") != null) {
	        		request.setAttribute("fname", session.getAttribute("fname2"));
	        		request.setAttribute("userType", session.getAttribute("userType2"));
	        }
	        else {
				request.setAttribute("fname", request.getAttribute("fname"));
				request.setAttribute("userType", request.getAttribute("userType"));
	        }
	            
	    } 
	    catch (SQLException sqle) {
	    		sqle.printStackTrace();
	    } 
	    catch (ClassNotFoundException cnfe) {
	    		cnfe.printStackTrace();
	    } 
	    finally {
		    	try {
		    		if (rs != null) {
		    			rs.close();
		    		}
		    		if (st != null) {
		    			st.close();
		    		}
		    		if (conn != null) {
		    			conn.close();
		    		}
		    	} 
		    	catch (SQLException sqle) {
		    		sqle.printStackTrace();
		    	}
	    }  

	    String nextJSP = "/projectlist.jsp";
		request.getRequestDispatcher(nextJSP).forward(request, response);
	}
}