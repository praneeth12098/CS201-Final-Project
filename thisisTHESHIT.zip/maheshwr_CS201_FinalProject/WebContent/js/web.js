/**
 * 
 */
//window.onload = init;
var socket; 
function connect(){
	console.log("In connect function");
	
	
	
	
	socket = new WebSocket("ws://localhost:8080/maheshwr_CS201_FinalProject/ws");
	socket.onmessage = onMessage;

	
	
}

function customize(){
	console.log("here");
	document.getElementById("textarea").style.display="";
}

function onMessage(event) {
    var message = JSON.parse(event.data);

    console.log("in onMessage function");
    
    if(message.action == "sendN"){
    		var text = message.description;
    		document.getElementById("notification").innerHTML = text; 
    }
}

function sendNotification(studentId, recruiterCompany, lname, recruiterID){
	
	console.log("studentid " + studentId);
	console.log("recruiterCompany " + recruiterCompany);
	console.log("lname " + lname);

	
	var xhttp=new XMLHttpRequest();

	xhttp.open("GET","SendEmailServlet?content="+document.getElementById("textarea").value+"&receiver="+studentId + "&recruiterCompany="+recruiterCompany + "&recruiterID="+recruiterID,false);
	xhttp.send();
	window.alert("Your message is successfully sent!");
	
	
	
	console.log("In send function");
	var Notification = {
	        action: "sendN",
	        description: "A recruiter wants to connect with you! Please check your email to respond."
	    };
	socket.send(JSON.stringify(Notification));
	
	
	
	
	
	
}