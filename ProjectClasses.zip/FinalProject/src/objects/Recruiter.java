package objects;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.List;

public class Recruiter extends Thread {
	private int recruiterID; 
	private String username; 
	private String password;
	private String fullName; 
	private String companyEmail;
	private String company;
	private List<Integer> connectedStudentIDs;
	private List<Integer> favoriteProjectIDs;
	private ObjectOutputStream oos;
	private ObjectInputStream ois;
	
	public Recruiter() {
		try {	
			Socket s = new Socket("localhost", 6789);
			ois = new ObjectInputStream(s.getInputStream());
			oos = new ObjectOutputStream(s.getOutputStream());
			this.start();
		}catch(IOException ioe) {
			System.out.println("ioe in Recruiter constructor: " + ioe.getMessage());
		}
	}
	
	public void run() {
		
		
	}
	
	public void main(String [] args) {
		Recruiter r = new Recruiter();
	}
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public int getRecruiterID() {
		return recruiterID;
	}
	public void setRecruiterID(int recruiterID) {
		this.recruiterID = recruiterID;
	}
	public String getCompanyEmail() {
		return companyEmail;
	}
	public void setCompanyEmail(String companyEmail) {
		this.companyEmail = companyEmail;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public List<Integer> getConnectedStudentIDs() {
		return connectedStudentIDs;
	}
	public void setConnectedStudentIDs(List<Integer> connectedStudentIDs) {
		this.connectedStudentIDs = connectedStudentIDs;
	}
	public List<Integer> getFavoriteProjectIDs() {
		return favoriteProjectIDs;
	}
	public void setFavoriteProjectIDs(List<Integer> favoriteProjectIDs) {
		this.favoriteProjectIDs = favoriteProjectIDs;
	}
}
