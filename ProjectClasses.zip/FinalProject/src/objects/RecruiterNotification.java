package objects;

public class RecruiterNotification {
	private String message;
	private Recruiter receiver;
	private String response;
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Recruiter getReceiver() {
		return receiver;
	}
	public void setReceiver(Recruiter receiver) {
		this.receiver = receiver;
	}
	public String getResponse() {
		return response;
	}
	public void setResponse(String response) {
		this.response = response;
	} 
}
