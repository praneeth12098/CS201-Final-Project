package objects;

public class StudentNotification {
	private String message;
	private Student receiver;
	private String response;
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Student getReceiver() {
		return receiver;
	}
	public void setReceiver(Student receiver) {
		this.receiver = receiver;
	}
	public String getResponse() {
		return response;
	}
	public void setResponse(String response) {
		this.response = response;
	} 
}
