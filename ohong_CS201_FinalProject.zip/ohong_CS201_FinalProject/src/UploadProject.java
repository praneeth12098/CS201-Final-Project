

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;


/**
 * Servlet implementation class UploadProject
 */
@WebServlet("/UploadProject")
@MultipartConfig
public class UploadProject extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UploadProject() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    		HttpSession session = request.getSession();
    		
    		String fname = request.getParameter("fname");
    		String userType = request.getParameter("userType");
    		System.out.println("fname: " + fname);
    		System.out.println("userType: " + userType);
    		session.setAttribute("fname2", fname);
    		session.setAttribute("userType2", userType);
    		
		String name = request.getParameter("title");
		String category = request.getParameter("category");
		String description = request.getParameter("description");
		String shortDescription = request.getParameter("shortDescription");
		String[] languages = request.getParameterValues("languages");
		Part codeFile = request.getPart("code");
		String fileName = codeFile.getSubmittedFileName();
		Part filePart = request.getPart("image");
		
		InputStream inputStream = null;
		if (codeFile != null) {
			inputStream = codeFile.getInputStream();
		}
	    Connection conn = null;
	    Statement st = null;
	    ResultSet rs = null;
	    PreparedStatement ps =  null;
	    try {
	    		Class.forName("com.mysql.jdbc.Driver");
	        conn = DriverManager.getConnection("jdbc:mysql://mydbinstance.cwkjzjcxdcml.us-east-2.rds.amazonaws.com:3306/mydb?user=cs201&password=finalproject&useSSL=false");
	        st = conn.createStatement();
	        
	        String query = "SELECT * FROM Student where Fname=?";
	        ps = conn.prepareStatement(query);
	        ps.setString(1, fname);
	        rs = ps.executeQuery();
	        int studentID = 0;
	        if (rs.next()) {
	        		studentID = rs.getInt("StudentID");
	        }
	        System.out.println("Student id: " + studentID);
	        rs.close();
	        
	        //insert new project into Project Table
        		query = "INSERT INTO Projects (ProjectID, Name, Category, ShortDescription, Description, Code, CodeBlob, Timestamp, StudentID)" + 
	        					"VALUES (?,?,?,?,?,?,?,?,?)";  
        		//ProjectID (0), Name, Category, ShortDescription, Description, Code, CodeBlob, Timestamp (null), StudentID
        		System.out.println(name);
			ps = conn.prepareStatement(query);
			inputStream = codeFile.getInputStream();
			ps.setInt(1, 0);
			ps.setString(2, name);
			ps.setString(3, category);
			ps.setString(4, shortDescription);
			ps.setString(5, description);
			ps.setString(6, fileName);
			ps.setBlob(7, inputStream);
			ps.setTimestamp(8, java.sql.Timestamp.valueOf(java.time.LocalDateTime.now()));
			ps.setInt(9, studentID);
			ps.executeUpdate(); 
			ps.close();
			
			//get new projectID
			rs = st.executeQuery("SELECT ProjectID FROM Projects WHERE Description='" + description + "' AND Name='" + name + "'");
			int projectID = 0;
			if (rs.next()) {
				projectID = rs.getInt("ProjectID");
			}
			rs.close();
			
			//insert the project's languages into Language table
			for (int i = 0; i < languages.length; i++) {
				query = "INSERT INTO Language (LanguageID, Language, fk_Language_ProjectID)" + 
						"VALUES (?,?,?)";   
				ps = conn.prepareStatement(query);
				ps.setInt(1, 0);
				ps.setString(2, languages[i]);
				ps.setInt(3, projectID);
				ps.executeUpdate(); 
				ps.close();
			}
			
			//get image(s) to insert into Image Table
			InputStream is = null;
			if (filePart != null) {
				is = filePart.getInputStream();
				query = "INSERT INTO Image (ImageBlob, fk_Image_Project_ID) VALUES (?,?)";
				ps = conn.prepareStatement(query);
				ps.setBlob(1, is);
				ps.setInt(2, projectID);
				ps.executeUpdate();
				ps.close();
			}
			
	    } 
	    catch (SQLException sqle) {
	    		sqle.printStackTrace();
	    } 
	    catch (ClassNotFoundException cnfe) {
	    		cnfe.printStackTrace();
	    } 
	    finally {
		    	try {
		    		if (rs != null) {
		    			rs.close();
		    		}
		    		if (st != null) {
		    			st.close();
		    		}
		    		if (conn != null) {
		    			conn.close();
		    		}
		    	} 
		    	catch (SQLException sqle) {
		    		sqle.printStackTrace();
		    	}
	    }  

//	    String nextJSP = "/WEB-INF/uploadSuccess.jsp";
	    String nextJSP = "/ViewProjects";
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(nextJSP);
		dispatcher.forward(request,response);
	}

	

}
