package networking;

import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.json.JsonObject;
import javax.websocket.Session;

public class SessionHandler { 
	private final Set<CustomSession> sessions = new HashSet<>();
    private Map<Session, CustomSession> sessionToId = new HashMap<Session, CustomSession>();
    int index = 0; 
    public void addSession(Session session) {
    		CustomSession customSession = new CustomSession(index, session);
		index++; 
    		sessions.add(customSession);
    		sessionToId.put(session, customSession);
        
    }

    public void removeSession(Session session) {
        CustomSession cs = sessionToId.get(session);
    		sessions.remove(cs);
    }

    public void sendToAllConnectedSessions(JsonObject message) {
    		System.out.println("Broadcasting a message.");
    		for (CustomSession session : sessions) {
            sendToSession(session, message);
        }
    }

    private void sendToSession(CustomSession session, JsonObject message) {
    		try {
            session.getSession().getBasicRemote().sendText(message.toString());
        } catch (IOException ex) {
            sessions.remove(session);
        }
    }

}