package networking;

import javax.websocket.Session;

public class CustomSession {
	private Session session;
	private int id;
	public Session getSession() {
		return session;
	}
	public void setSession(Session session) {
		this.session = session;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	} 
	
	public CustomSession(int index, Session session) {
		this.id = index;
		this.session = session; 
	}
	
}
