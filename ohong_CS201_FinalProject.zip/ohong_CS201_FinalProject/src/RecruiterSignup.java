

import java.io.IOException;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.websocket.Session;

import java.sql.PreparedStatement;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Servlet implementation class StudentSignup
 */
@WebServlet("/recruiterSignup")
public class RecruiterSignup extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	
	static private String hexEncode( byte[] aInput){
	    StringBuffer result = new StringBuffer();
	    char[] digits = {'0', '1', '2', '3', '4','5','6','7','8','9','a','b','c','d','e','f'};
	    for (int idx = 0; idx < aInput.length; ++idx) {
	      byte b = aInput[idx];
	      result.append( digits[ (b&0xf0) >> 4 ] );
	      result.append( digits[ b&0x0f] );
	    }
	    return result.toString();
	  }  
	
   
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//get parameters from form:
		String fname = request.getParameter("fname");
		String lname = request.getParameter("lname");
		String username = request.getParameter("username");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		String passwordverify = request.getParameter("passwordverify");
		String company = request.getParameter("company");
	
		
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		
		PreparedStatement ps = null;
		
		try {
		      MessageDigest sha = MessageDigest.getInstance("SHA-1");
		      byte[] hash = sha.digest(password.getBytes());
		      
		      String hashedPwd = hexEncode(hash);
		      
		      System.out.println("password: " + password + " hashedPwd: " + hashedPwd);
		      
		      
		      try {
					Class.forName("com.mysql.jdbc.Driver");
					conn = DriverManager.getConnection("jdbc:mysql://mydbinstance.cwkjzjcxdcml.us-east-2.rds.amazonaws.com:3306/mydb?user=cs201&password=finalproject&useSSL=false");
				
					st = conn.createStatement();
					
					ps = conn.prepareStatement("INSERT INTO Recruiter (Username, Password, Fname, Email, CompanyName, Lname)"
							+ "VALUES (?, ?, ?, ?, ?, ?)"); 
					
					ps.setString(1, username);
					ps.setString(2, hashedPwd);
					ps.setString(3, fname);
					ps.setString(4, email);
					ps.setString(5, company);
					ps.setString(6, lname);
					
					
					int i = ps.executeUpdate();
					
					if (i > 0) {
						//dispatch to login
						response.sendRedirect(request.getContextPath() + "/layouts/login.jsp");
						
					}
					
					
				} catch  (SQLException sqle) {
					System.out.println("sqle: " + sqle.getMessage());
				} catch (ClassNotFoundException cnfe) {
					System.out.println("cnfe: " + cnfe.getMessage());
				} finally {
					try {
						
						if (st != null) {
							st.close();
						} 
						if (conn != null) {
							conn.close();
						}
					} catch (SQLException sqle) {
						System.out.println("sqle closing stuff: " + sqle.getMessage());
					}
				}
		            
		    }
		    catch (NoSuchAlgorithmException ex){
		      System.out.println("No such algorithm found in JRE.");
		    }
		
	}

}


