CS201-Final-Project: Project Showcase

Group Members: Praneeth Batte, Raghav Maheshwari, Olivia Hong, Ana Lucia Rescala, Tuling Zhao

Description: This web application that acts as a “reverse career fair.” There will be 2 types of users, students and recruiters. Students can upload their school and personal projects to the website’s database and companies would see those projects. However, the students would remain anonymous to the companies, to remove any hiring bias. Guest users would be able to see projects but not be able to ask for the student contact information.

How to run: To run the project, run "index.jsp" which is located in the WebContent folder.
The project requires connection to a remote Amazon database, and there are 4 jars needed which are already in the project.

What Works: Account registration, login, and guest functionality all work. Recruiters can contact students, which will send an email to the student. If the student accepts/rejects, the recruiter will get an email. Students can upload projects, and these projects can be viewed on the website. 