/**
 * 
 */
//window.onload = init;
var socket; 
function connect(){
	console.log("In connect function");
	socket = new WebSocket("ws://localhost:8080/maheshwr_CS201_FinalProject/ws");
	socket.onmessage = onMessage;
	
	socket.onopen = function(event){
		document.getElementById("test").innerHTML += "Connected!"; 
	}
	
	socket.onclose = function(event){
		document.getElementById("test").innerHTML += "Closing!"; 
	}
}

function onMessage(event) {
    var message = JSON.parse(event.data);

    console.log("in onMessage function");
    
    if(message.action == "sendN"){
    		var text = message.description;
    		document.getElementById("notification").innerHTML += text; 
    }
}

function sendNotification(){
	console.log("In send function");
	var Notification = {
	        action: "sendN",
	        description: "I am sending a message to everyone."
	    };
	socket.send(JSON.stringify(Notification));
}