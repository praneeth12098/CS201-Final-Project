
import java.io.IOException;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.websocket.Session;

import java.sql.PreparedStatement;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
/**
 * Servlet implementation class Login
 */
@WebServlet("/login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	static private String hexEncode( byte[] aInput){
	    StringBuffer result = new StringBuffer();
	    char[] digits = {'0', '1', '2', '3', '4','5','6','7','8','9','a','b','c','d','e','f'};
	    for (int idx = 0; idx < aInput.length; ++idx) {
	      byte b = aInput[idx];
	      result.append( digits[ (b&0xf0) >> 4 ] );
	      result.append( digits[ b&0x0f] );
	    }
	    return result.toString();
	  }  
	
	
	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpServlet#service(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 //get parameters from form:
		
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		
		//System.out.println(username + " " + password);
		
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		
		PreparedStatement ps = null;
		
		try {
		      MessageDigest sha = MessageDigest.getInstance("SHA-1");
		      byte[] hash = sha.digest(password.getBytes());
		      
		      String hashedPwd = hexEncode(hash);
		      
		      try {
					Class.forName("com.mysql.jdbc.Driver");
					conn = DriverManager.getConnection("jdbc:mysql://localhost/mydb?user=root&password=root&useSSL=false");
				
					st = conn.createStatement();
					
					boolean successLogin = false;
					
					
					ps = conn.prepareStatement("SELECT * FROM student where (Username=? OR Email=?) AND Password=?");
					ps.setString(1, username);
					ps.setString(2, username);
					ps.setString(3, hashedPwd);
					
					rs = ps.executeQuery();
					
					HttpSession session = request.getSession();
					
					if (rs.next()) {
						//successful login:
						//System.out.println("first name: " + rs.getString("Fname"));
						successLogin = true;
						
						
				        
						//set the session variables:
						session.setAttribute("username", rs.getString("Username"));
						session.setAttribute("fname", rs.getString("Fname"));
						session.setAttribute("lname", rs.getString("Lname"));
						session.setAttribute("email", rs.getString("Email"));
						session.setAttribute("school", rs.getString("School"));
						session.setAttribute("major", rs.getString("Major"));
						session.setAttribute("standing", rs.getString("Standing"));
						
						
				        session.setAttribute("userType", "student");
				        
				       
						
				        
						
						response.sendRedirect(request.getContextPath() + "/ViewProjects");
						
					} 
					
					
					
					ps = conn.prepareStatement("SELECT * FROM recruiter where (Username=? OR Email=?) AND Password=?");
					ps.setString(1, username);
					ps.setString(2, username);
					ps.setString(3, hashedPwd);
					
					rs = ps.executeQuery();
					
					
					
					
					if (rs.next()) {
						//successful login:
						//System.out.println("first name: " + rs.getString("Fname"));
						successLogin = true;
						
					
						//set the session 
				        session.setAttribute("username", rs.getString("Username"));
						session.setAttribute("fname", rs.getString("Fname"));
				        session.setAttribute("lname", rs.getString("Lname"));
				        session.setAttribute("company", rs.getString("CompanyName"));
				        session.setAttribute("userType", "recruiter");
				        
				       
				        response.sendRedirect(request.getContextPath() + "/ViewProjects");
						
						
					} 
					
					if (!successLogin) {
						System.out.println("Incorrect Login Credentials");
						
						session.invalidate();
						response.sendRedirect(request.getContextPath() + "/layouts/incorrectLogin.jsp");
					}
					
					
					
				
					
				} catch  (SQLException sqle) {
					System.out.println("sqle: " + sqle.getMessage());
				} catch (ClassNotFoundException cnfe) {
					System.out.println("cnfe: " + cnfe.getMessage());
				} finally {
					try {
						
						if (st != null) {
							st.close();
						} 
						if (conn != null) {
							conn.close();
						}
					} catch (SQLException sqle) {
						System.out.println("sqle closing stuff: " + sqle.getMessage());
					}
				}
		
		      
		      
		      
		      
		} catch (NoSuchAlgorithmException ex){
		      System.out.println("No such algorithm found in JRE.");
		}
	}

}
